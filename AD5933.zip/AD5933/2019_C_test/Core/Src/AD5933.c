//
// Created by YYB on 2023/7/13.
//
//Basic define
#include "stm32f3xx_hal.h"
#include "AD5933.h"
#include "i2c.h"
void start_frequency_set(float start_frequency){
    uint8_t s_fre_low = 0;
    uint8_t s_fre_mid = 0;
    uint8_t s_fre_high = 0;
    s_fre_low = ((int) ((start_frequency / (CLK / 4)) * N) & 0xFF);
    s_fre_mid = ((((int) ((start_frequency / (CLK / 4)) * N)) >> 8) & 0xFF);
    s_fre_high = ((((int) ((start_frequency / (CLK / 4)) * N)) >> 16) & 0xFF);
    uint8_t s_fre_1[2] = {reg_start_frequency_1, s_fre_high};
    uint8_t s_fre_2[2] = {reg_start_frequency_2, s_fre_mid};
    uint8_t s_fre_3[2] = {reg_start_frequency_3, s_fre_low};
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, s_fre_3, sizeof(s_fre_3), 100);
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, s_fre_2, sizeof(s_fre_2), 100);
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, s_fre_1, sizeof(s_fre_1), 100);
}

void step_frequency_set(float step_frequency){
    uint8_t i_fre_low = 0;
    uint8_t i_fre_mid = 0;
    uint8_t i_fre_high = 0;
    i_fre_low = ((int) ((step_frequency / (CLK / 4)) * N) & 0xFF);
    i_fre_mid = ((((int) ((step_frequency / (CLK / 4)) * N)) >> 8) & 0xFF);
    i_fre_high = ((((int) ((step_frequency / (CLK / 4)) * N)) >> 16) & 0xFF);
    uint8_t i_fre_1[2] = {reg_frequency_increments_1, i_fre_high};
    uint8_t i_fre_2[2] = {reg_frequency_increments_2, i_fre_mid};
    uint8_t i_fre_3[2] = {reg_frequency_increments_3, i_fre_low};
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, i_fre_3, sizeof(i_fre_3), 100);
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, i_fre_2, sizeof(i_fre_2), 100);
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, i_fre_1, sizeof(i_fre_1), 100);
}

void sweep_number_set(int sweep_number){
    uint8_t swp_num_low = (sweep_number & 0xFF);
    uint8_t swp_num_high = ((sweep_number >> 8) & 0x1);
    uint8_t swp_num_1[2] = {reg_increments_1, swp_num_high};
    uint8_t swp_num_2[2] = {reg_increments_2, swp_num_low};
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, swp_num_2, sizeof(swp_num_2), 100);
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, swp_num_1, sizeof(swp_num_1), 100);
}


void time_period_set(){
    uint8_t time_period_mutiply[2] = {reg_time_period_1, 0x00};
    uint8_t time_period_number[2] = {reg_time_period_2, 0x0F};
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, time_period_number, sizeof(time_period_number), 100);
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, time_period_mutiply, sizeof(time_period_mutiply), 100);
}

uint8_t standby_mode[2] = {reg_control_1, 0xB1};
void standby_set(){
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, standby_mode, sizeof(standby_mode), 100);
}

uint8_t initialize[2] = {reg_control_1, 0x11};
void initialize_set(){
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, initialize, sizeof(initialize), 100);
}

uint8_t sweep_start[2] = {reg_control_1, 0x21};
void sweep_start_set(){
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, sweep_start, sizeof(sweep_start), 100);//Enable the sweep mode
}

uint8_t increasing_frequency[2] = {reg_control_1, 0x31};
void frequency_increase(){
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, increasing_frequency, sizeof(increasing_frequency), 100);
}

uint8_t keeping_frequency[2] = {reg_control_1, 0x41};
void frequency_keep(){
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, keeping_frequency, sizeof(keeping_frequency), 100);
}

int complement_cal(uint8_t high,uint8_t low){
    uint16_t tmp = high << 8 + low;
    uint8_t judge = high & 128;//1000 0000,judge the highest bit is 1/0
    judge = judge >> 7;
    if(judge == 1){//minus
        tmp = tmp - 1;
        tmp = tmp ^ 63335;//1111 1111 1111 1111,negation
        return (-1)*tmp;
    }else{
        return tmp;
    }
}

int Get_real(){
    uint8_t real[1] = {reg_real_number_1};//send address
    uint8_t real1[1] = {reg_real_number_2};
    uint8_t real_read[1] = {0};//Stores real part data
    uint8_t real_read1[1] = {0};
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, real, sizeof(real), 100);
    HAL_I2C_Master_Receive(&hi2c1, chipAddress, real_read, sizeof(real_read), 100);//Read real part
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, real1, sizeof(real), 100);
    HAL_I2C_Master_Receive(&hi2c1, chipAddress, real_read1, sizeof(real_read1), 100);//Read real part
    return complement_cal(real[0],real1[0]);
}

int Get_imaginary(){
    uint8_t imaginary[1] = {reg_imaginary_number_1};//send address
    uint8_t imaginary1[1] = {reg_imaginary_number_2};
    uint8_t imaginary_read[1] = {0};//Stores virtual part data
    uint8_t imaginary_read1[1] = {0};
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, imaginary, sizeof(imaginary), 100);
    HAL_I2C_Master_Receive(&hi2c1, chipAddress, imaginary_read, sizeof(imaginary_read), 100);
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, imaginary1, sizeof(imaginary1), 100);
    HAL_I2C_Master_Receive(&hi2c1, chipAddress, imaginary_read1, sizeof(imaginary_read1), 100);
    return complement_cal(imaginary_read[0],imaginary_read1[0]);
}

int condition_read_D2(){
    uint8_t condition[1] = {reg_condition};//send address
    uint8_t condition_read[1] = {0};//Store the read status information
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, condition, sizeof(condition), 100);
    HAL_I2C_Master_Receive(&hi2c1, chipAddress, condition_read, sizeof(condition_read),100);//Read status information
    int D2 = (condition_read[0] & 0x04) >> 2;//Get D2 information
    return D2;
}

int condition_read_D1(){
    uint8_t condition[1] = {reg_condition};//send address
    uint8_t condition_read[1] = {0};//Store the read status information
    HAL_I2C_Master_Transmit(&hi2c1, chipAddress, condition, sizeof(condition), 100);
    HAL_I2C_Master_Receive(&hi2c1, chipAddress, condition_read, sizeof(condition_read),100);//Read status information
    int D1 = (condition_read[0] & 0x02) >> 1;//Get D1 information
    return D1;
}
