//
// Created by YYB on 2023/7/13.
//
#include "stm32f3xx_hal.h"
//Basic define
#define N 134217728 //2^27
#define CLK 16.776e6 //Internal clock
//Device address
#define chipAddress  0x1A

//Register address definition
#define reg_control_1  0x80
#define reg_control_2  0x81
#define reg_start_frequency_1  0x82
#define reg_start_frequency_2  0x83
#define reg_start_frequency_3  0x84

#define reg_frequency_increments_1  0x85
#define reg_frequency_increments_2  0x86
#define reg_frequency_increments_3  0x87

#define reg_increments_1  0x88
#define reg_increments_2  0x89

#define reg_time_period_1  0x8A
#define reg_time_period_2  0x8B

#define reg_condition  0x8F

#define reg_tmpdata_1  0x92
#define reg_tmpdata_2  0x93

#define reg_real_number_1  0x94
#define reg_real_number_2  0x95

#define reg_imaginary_number_1  0x96
#define reg_imaginary_number_2  0x97

//Initial configuration
void standby_set();//设置待机模式
void sweep_start_set();//开启扫频模式，等待进一步指令
void frequency_increase();//在扫频模式开启的前提下，步进频率
void frequency_keep();//在扫频模式开启的前提下，保持频率
void initialize_set();//初始化（配置起始频率，步进频率，步进数，时间周期后）
//Parameter setting
void start_frequency_set(float );//将初始化频率配置进寄存器
void step_frequency_set(float );//将步进频率配置进寄存器
void sweep_number_set(int );//将步进次数配置进寄存器
void time_period_set();//设置时间周期，这里设定为15个，可以通过更改AD5933.c文件中的变量来更改
//Read the data
int complement_cal(uint8_t,uint8_t);//补码转原码，通过这一函数将两个寄存器里的数据读出十进制表达
int Get_real();//读取实部寄存器
int Get_imaginary();//读取虚部寄存器
int condition_read_D1();//读取状态寄存器中的D1
int condition_read_D2();//读取状态寄存器中的D2

#ifndef INC_2019_C_TEST_AD5933_H
#define INC_2019_C_TEST_AD5933_H

#endif //INC_2019_C_TEST_AD5933_H
